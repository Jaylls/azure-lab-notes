# 📖 Comandos Azure CLI Essenciais

## 📌 Autenticação

```bash
az login
az account show
```

## 📌 Resource Group

```bash
az group create --name MeuRG --location eastus
az group list --output table
az group delete --name MeuRG
```

## 📌 Máquinas Virtuais

```bash
az vm list --output table
az vm start --name VMTeste --resource-group MeuRG
az vm stop --name VMTeste --resource-group MeuRG
```
