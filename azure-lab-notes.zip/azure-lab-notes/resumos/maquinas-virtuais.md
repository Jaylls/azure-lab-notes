# 📖 Máquinas Virtuais no Azure

## 📌 Conceitos

- VM é uma instância de computador virtualizada na nuvem.
- Escolha da Image (SO) e SKU (tamanho da VM)
- Network Security Group (NSG) para definir regras de acesso
- Disk Managed para armazenamento

## 📈 Comandos Azure CLI

```bash
# Criar resource group
az group create --name MeuResourceGroup --location eastus

# Criar VM
az vm create   --resource-group MeuResourceGroup   --name MinhaVM   --image UbuntuLTS   --size Standard_B2s   --admin-username azureuser   --generate-ssh-keys

# Listar VMs
az vm list --output table

# Parar VM
az vm stop --name MinhaVM --resource-group MeuResourceGroup
```
