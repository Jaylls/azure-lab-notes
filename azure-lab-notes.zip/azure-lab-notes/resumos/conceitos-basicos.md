# 📖 Conceitos Básicos do Azure

## 📌 Estrutura Hierárquica

- **Conta Azure**: Conta associada a um email.
- **Subscription**: Contêiner para recursos, com controle de cobrança.
- **Resource Group**: Grupo lógico de recursos relacionados.
- **Resource**: Serviço criado dentro de um resource group (VM, Storage, etc).

## 📈 Regiões e Zonas

- **Region**: Localização geográfica do datacenter (Ex: East US, Brazil South)
- **Availability Zone**: Datacenters isolados dentro de uma região para alta disponibilidade.

## 📌 Principais Serviços

- **VMs**: Máquinas Virtuais
- **Blob Storage**: Armazenamento de objetos
- **Virtual Network (VNet)**: Rede privada na nuvem
- **App Services**: Hospedagem de aplicações web
- **Azure SQL Database**: Banco de dados gerenciado
