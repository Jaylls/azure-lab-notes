# 💡 Boas Práticas no Azure

- Defina uma convenção de nomes (Ex: vm-prod-web-01)
- Organize recursos por Resource Groups
- Utilize Tags para categorização
- Defina políticas de segurança (NSG, RBAC)
- Mantenha backups e snapshots periódicos
- Utilize Availability Sets ou Zones para alta disponibilidade
- Sempre revise custos no Azure Cost Management
